using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

public class Player1Paddle : MonoBehaviour
{
    public float speed;
    private int move;

    public SpriteRenderer spriteRenderer;


    // Start is called before the first frame update
    void Start()
    {
        if (this.CompareTag("Player"))
        {
            spriteRenderer.color = SaveColors.Instance.PlayerColor;
        }
        else
        {
            spriteRenderer.color = SaveColors.Instance.EnemyColor;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            move = 1;
        } else if (Input.GetKey(KeyCode.S)) {
            move = -1;
        } else { move = 0; }

        //Atualiza a posicao pra dar impressao de movimento somando a posicao atual com o vetor da direcao do movimento * o sentido * a velocidade * o DeltaTime
        Vector3 newPosition = transform.position + Vector3.up * move * speed * Time.deltaTime;

        //Esse Comando garante que o valor da nova posicao nao passe do min ou max da funcao
        newPosition.y = Mathf.Clamp(newPosition.y, -5.3f, 5.3f);

        //setta a nova posicao
        transform.position = newPosition;
    }
}
