using System.Collections;
using System.Collections.Generic;
using UnityEditor.Build.Content;
using UnityEngine;

public class BallController : MonoBehaviour
{
    public GameManager GameManager;

    public int rng;
    
    private Rigidbody2D rb;
    
    public Vector2 initialSpeed;
    public Vector2 actualSpeed = new Vector2();
    
    System.Random random = new System.Random();

    public void ResetBall()
    {
        rng = Random.Range(0, 1);
        if (rng == 0 )
        {
            initialSpeed.x*=-1;
        }

        rng = Random.Range(0, 1);
        if (rng == 0)
        {
            initialSpeed.y *= -1;
        }


        transform.position = Vector3.zero;
        if (rb ==null) rb = GetComponent<Rigidbody2D>();
        rb.velocity = initialSpeed;
    }


    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            actualSpeed = rb.velocity;
            actualSpeed.y = -actualSpeed.y;
            rb.velocity = actualSpeed;
        }

        else if (collision.gameObject.CompareTag("Player")|| collision.gameObject.CompareTag("Enemy"))
        {
            actualSpeed = rb.velocity;
            if (actualSpeed.x < 0)
            {
                actualSpeed.x -= 3;
            } else
            {
                actualSpeed.x += 3;
            }
            actualSpeed.x = -actualSpeed.x;
            rb.velocity = actualSpeed;
            
        }

        else if (collision.gameObject.CompareTag("EnemyWall"))
        {
            GameManager.PlayerPointed();
        }

        else if (collision.gameObject.CompareTag("PlayerWall"))
        {
            GameManager.EnemyPointed();
        }
    }


}
