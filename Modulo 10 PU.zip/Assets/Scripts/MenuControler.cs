using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class MenuControler : MonoBehaviour
{

    public TextMeshProUGUI lastWinner;
    public string lastWinnerText;

    // Start is called before the first frame update
    void Start()
    {
        SaveColors.Instance.Reset();
        lastWinnerText= SaveColors.Instance.GetLastWinner();
        if (lastWinnerText != "")
        {
            lastWinner.text = "�ltimo vencedor: " + lastWinnerText;
        }
        else {
            lastWinner.text = "";
        }
    }


    public void ClearSaveButton() { 
        SaveColors.Instance.ClearSave();
    }
}
