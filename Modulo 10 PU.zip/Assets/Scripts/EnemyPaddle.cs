using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class EnemyPaddle : MonoBehaviour
{
    
    public SpriteRenderer spriteRenderer;
    public float Speed;
    private Rigidbody2D rb;

    private GameObject ball;

    void Start()
    {
        if (this.CompareTag("Player"))
        {
            spriteRenderer.color = SaveColors.Instance.PlayerColor;
        }
        else
        {
            spriteRenderer.color = SaveColors.Instance.EnemyColor;
        }

        rb = GetComponent<Rigidbody2D>();
        ball = GameObject.Find("Ball");
    }

    // Update is called once per frame
    void Update()
    {
        float TargetY = Mathf.Clamp(ball.transform.position.y, -5f, 5f);
        Vector2 TargetPosition= new Vector2(transform.position.x,TargetY);
        transform.position=Vector2.MoveTowards(transform.position,TargetPosition,Speed*Time.deltaTime);
    }
}
