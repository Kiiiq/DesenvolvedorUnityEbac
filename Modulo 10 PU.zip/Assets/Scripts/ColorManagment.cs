using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;


public class ColorManagment : MonoBehaviour
{
    public Button uiButton;
    public SpriteRenderer paddleReference;


    public void OnClick()
    {

        
        paddleReference.color = uiButton.colors.normalColor;

        if (uiButton.CompareTag("Player"))
        {
            Debug.Log("?");
            SaveColors.Instance.PlayerColor = paddleReference.color;
        }
        else
        {
            Debug.Log("!");
            SaveColors.Instance.EnemyColor = paddleReference.color;
        }
    }

}
