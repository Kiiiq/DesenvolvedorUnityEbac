using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using UnityEngine;

public class SaveColors : MonoBehaviour
{
    public Color PlayerColor = Color.white;
    public Color EnemyColor = Color.white;

    private static SaveColors _instance;
    // Propriedade est�tica para acessar a inst�ncia
    public GameManager GameManager;

    public string namePlayer;
    public string nameEnemy;

    public string GetName(GameObject gameObject)
    {
        if (GameManager.PlayerWon == true)
        {
            if (!string.IsNullOrEmpty(namePlayer))
            {
                return nameEnemy;
            } else 
            { return "player 2"; }
        }
        else
        {
            if (!string.IsNullOrEmpty(namePlayer))
            {
                return namePlayer;
            } else { 
                return "player 1";
            }
        }
    }

    public static SaveColors Instance
    {
        get
        {
            if (_instance == null)
            {
                // Procure a inst�ncia na cena
                _instance = FindObjectOfType<SaveColors>();
                // Se n�o encontrar, crie uma nova inst�ncia
                if (_instance == null)
                {
                    GameObject singletonObject = new GameObject(typeof(SaveColors).Name);
                    _instance = singletonObject.AddComponent<SaveColors>();
                }
            }
            return _instance;
        }
    }

    private void Awake()
    {
        // Garanta que apenas uma inst�ncia do Singleton exista
        if (_instance != null && _instance != this)
        {
            Destroy(this.gameObject);
            return;
        }
        // Mantenha o Singleton vivo entre as cenas
        DontDestroyOnLoad(this.gameObject);
    }


    public void Reset()
    {
        PlayerColor = Color.white;
        EnemyColor = Color.white;
        nameEnemy = "";
        namePlayer = "";
    }

    public void SaveWinner(string winner)
    {
        PlayerPrefs.SetString("SavedWinner", winner);
    }
    public string GetLastWinner()
    {
     
        return PlayerPrefs.GetString("SavedWinner");
        
    }

    public void ClearSave()
    {
        PlayerPrefs.DeleteAll();
    }
}
