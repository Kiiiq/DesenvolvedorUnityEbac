using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public int winCondition;
    private int enemyPoints = 0;
    private int playerPoints = 0;

    private string Menu = "Menu";

    public bool PlayerWon;

    public GameObject Game;
    public GameObject RestartQ;

    public TextMeshProUGUI textPlayerPoints;
    public TextMeshProUGUI textEnemyPoints;
    public TextMeshProUGUI Announcements;

    public Transform enemy;
    public Transform player;

    public string LastWinner;

    public BallController ballController;

    void Start()
    {
        StartGame();
    }

    public void StartGame()
    {
        Announcements.text = ("");
        RestartQ.SetActive(false);
        //Set the paddles at the initial position
        enemy.position = new Vector3(9.5f, 0f, 0f);
        player.position = new Vector3(-9.5f, 0f, 0f);
        ballController.ResetBall();

        enemyPoints = 0;
        playerPoints = 0;

        textEnemyPoints.text= enemyPoints.ToString();
        textPlayerPoints.text= playerPoints.ToString();
    }

    public void PlayerPointed()
    {
        playerPoints += 1;
        textPlayerPoints.text = playerPoints.ToString();
        ballController.ResetBall();
        CheckWin();
    }

    public void EnemyPointed() { 
        enemyPoints += 1;
        textEnemyPoints.text = enemyPoints.ToString();
        ballController.ResetBall();
        CheckWin();
    }

    public void CheckWin() { 
    if (enemyPoints == winCondition)
        {
            PlayerWon= false;
            StartCoroutine(Lose());
        }
    else if(playerPoints==winCondition){
            PlayerWon = true;
            StartCoroutine(Win());
        }
    }

    public IEnumerator Win()
    {
        Game.SetActive(false);
        Announcements.text = (SaveColors.Instance.namePlayer + " WON!!!");
        yield return new WaitForSeconds(1);
        RestartQ.SetActive(true);
        SaveColors.Instance.SaveWinner(SaveColors.Instance.namePlayer);

    }

    public IEnumerator Lose(){
        Game.SetActive(false);
        Announcements.text = (SaveColors.Instance.nameEnemy + " WON!!!");
        yield return new WaitForSeconds(1);
        RestartQ.SetActive(true);
        SaveColors.Instance.SaveWinner(SaveColors.Instance.nameEnemy);
    }

    private void Update()
    {
        if (!Game.activeInHierarchy)
        {
            if(Input.GetKeyDown(KeyCode.Space))
            {
                Game.SetActive(true);
                StartGame();
            } else if (Input.GetKeyDown(KeyCode.Escape))
            {
                SceneManager.LoadScene(Menu);
            }


        }
    }

}
