using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class NameSaver : MonoBehaviour
{
    public bool isPlayer;
    public TMP_InputField inputField;
    private void Start()
    {
        if (inputField != null & this.CompareTag("Player")) {
            SaveColors.Instance.namePlayer = "Player 1";
        } else if (inputField != null)
        {
            SaveColors.Instance.namePlayer = "Player 2";
        }
        inputField.onValueChanged.AddListener(UpdateName);
    }
    public void UpdateName(string name)
    {
        if (this.CompareTag("Player"))
            SaveColors.Instance.namePlayer = name;
        else
            SaveColors.Instance.nameEnemy = name;
    }
}
