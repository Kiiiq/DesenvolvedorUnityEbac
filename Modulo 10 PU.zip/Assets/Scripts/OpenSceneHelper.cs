using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class OpenSceneHelper : MonoBehaviour
{
    public string Singleplayer = "GameSinglePlayer";
    public string Multiplayer = "GameMultiplayer";
    public string Menu = "Menu";
    public string ChooseColor = "ChooseColor";

    public void GoSinglePlayer()
    {
        SceneManager.LoadScene(Singleplayer);
    }

    public void GoMultiplayer()
    {
        SceneManager.LoadScene(Multiplayer);
    }

    public void GoBack() {
        SceneManager.LoadScene(Menu);
    }

    public void GoChooseColor() {
         SceneManager.LoadScene(ChooseColor);
    }
}
