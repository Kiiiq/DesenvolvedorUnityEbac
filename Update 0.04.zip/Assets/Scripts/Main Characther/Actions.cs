using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Actions : MonoBehaviour
{
    public enum attacking { Right=0, Left=1, Up=2, Down=3 };

    public Vector3 attackLeft = new Vector3(0,180,0);
    public Vector3 attackUp = new Vector3(0,0,90);
    public Vector3 attackRight = new Vector3(0,0,0);
    public Vector3 attackDown = new Vector3(180,0,90);
    
    public Movement movement;

    public GameObject Hitbox, Spell;

    public KeyCode attackKey = KeyCode.X, attackUpKey = KeyCode.UpArrow, attackDownKey = KeyCode.DownArrow, spellKey=KeyCode.A;

    public bool isAttacking, isCasting;

    public int damage, direction, maxStamina, stamina, staminaToCast;

    public float attackSpeed, timeToCast;
    
    void Awake(){
        stamina=maxStamina;
    }

    void Update()
    {
       if(Input.GetKeyDown(attackKey) && !movement.isDashing && !isAttacking && !isCasting)
        {
            StartCoroutine(Attack());
        } else if(Input.GetKeyDown(spellKey) && !movement.isDashing && !isAttacking && stamina>=staminaToCast)
        {
            StartCoroutine(CastSpell());
        }
    }

    IEnumerator Attack()
    {
        if(Input.GetKey(attackUpKey))
        {           
            direction = (int)attacking.Up;
            isAttacking = true;
            Instantiate(Hitbox, this.transform.position + new Vector3(0, 1, 0), Quaternion.Euler(attackUp), this.transform);
            yield return new WaitForSeconds(attackSpeed);
            isAttacking = false;
        
        } else if(Input.GetKey(attackDownKey) && !movement.onFloor) 
        {
            direction = (int)attacking.Down;
            Debug.Log("Down");
            isAttacking = true;
            Instantiate(Hitbox, this.transform.position + new Vector3(0, -1, 0), Quaternion.Euler(attackDown), this.transform);
            yield return new WaitForSeconds(attackSpeed);
            
            isAttacking = false;
        }
        else if (movement.facingRight)
        {
            direction = (int)attacking.Right;
            isAttacking = true;
            Instantiate(Hitbox, this.transform.position+new Vector3(0.5f,0,0), Quaternion.Euler(attackRight), this.transform);
            yield return new WaitForSeconds(attackSpeed);
            isAttacking = false;
        } 
        else
        {
            direction = (int)attacking.Left;
            isAttacking = true;
            Instantiate(Hitbox, this.transform.position + new Vector3(-0.5f, 0, 0), Quaternion.Euler(attackLeft), this.transform);
            yield return new WaitForSeconds(attackSpeed);
            isAttacking = false;
        }
    }

    IEnumerator CastSpell(){
        if(movement.facingRight)
        {
            stamina-=staminaToCast;
            Debug.Log("Casting");
            isCasting=true;
            movement.playerRigidbody.velocity= new Vector2(0,0);
            movement.playerRigidbody.gravityScale = 0;
            yield return new WaitForSeconds(timeToCast);
            Instantiate(Spell,this.transform.position,Quaternion.Euler(0,0,0), this.transform);
            movement.playerRigidbody.gravityScale =movement.Gravity;
            isCasting=false;
        } else {
            stamina-=staminaToCast;
            Debug.Log("Casting");
            isCasting=true;
            movement.playerRigidbody.velocity= new Vector2(0,0);
            movement.playerRigidbody.gravityScale = 0;
            yield return new WaitForSeconds(timeToCast);
            Instantiate(Spell,this.transform.position,Quaternion.Euler(0,180,0), this.transform);
            movement.playerRigidbody.gravityScale =movement.Gravity;
            isCasting=false;
        }
    }
}


