using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellScript : MonoBehaviour
{

    public Rigidbody2D SpellRigidbody;
    public float speed, attackDuration;
    public Movement movement;

    // Start is called before the first frame update
    void Start()
    {
        SpellRigidbody = GetComponent<Rigidbody2D>();
        StartCoroutine(TimeToDestroy());
        movement = GetComponentInParent<Movement>();
        if (movement.facingRight)
        {
            SpellRigidbody.velocity = new Vector2(speed, 0);
        }
        else
        {
            SpellRigidbody.velocity = new Vector2(-speed, 0);
        }

    }

    IEnumerator TimeToDestroy()
    {
        yield return new WaitForSeconds(attackDuration);
        Destroy(this.gameObject);
    }

}
